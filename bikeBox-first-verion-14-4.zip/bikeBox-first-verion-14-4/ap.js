var mapp = L.map('mapp').setView([51.505, -0.09], 6);
L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png').addTo(mapp);
mapp.locate({setView: true, maxZoom: 6});
//  map.on('locationfound', function(e) {
//     alert("ooo")

//  });



let LockerTwo = L.marker([49.8988,10.9028]).addTo(mapp).bindPopup(`Bamberg Bahnhof  <a href="#">select location</a> 1 free`).openPopup();


$("[data-toggle=popover]").popover();


