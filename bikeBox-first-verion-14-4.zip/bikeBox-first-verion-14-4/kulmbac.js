var map = L.map('map').setView([51.505, -0.09], 6);
L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png').addTo(map);
map.locate({setView: true, maxZoom: 6});
//  map.on('locationfound', function(e) {
//     alert("ooo")

//  });



let LockerKulmbach = L.marker([50.10068, 11.45032]).addTo(map).bindPopup(`Kulmbah Bahnhof  <a href="place.html">select location</a> 16 free`).openPopup();




// swiper


const swiper = new Swiper('.swiper', {
  slidesPerView: 1,
  spaceBetween: 10,
 
  breakpoints: {
    500: {
      slidesPerView: 2,
      spaceBetween: 10,
    },
    800: {
      slidesPerView: 2,
      spaceBetween: 10,
    },
    900: {
      slidesPerView: 3,
      spaceBetween: 10,
    },
  },
  // pagination: {
  //   el: '.swiper-pagination',
  //   clickable: true,
  // },
  // Navigation arrows
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
});


lightbox.option({

  alwaysShowNavOnTouchDevices	:true
})



